This folder contains all the 3rd party tools and libraries that are either 
deployed or make up the test environment.

All tools and code are provided here for ease of access by developers 
wishing to work on the project. The Licence for OpenCover does not apply 
to these utilities and code and everyone should respect those licenses where 
applicable.

If you believe code has been placed against the licence, please contact so 
that we may remedy the situation.

